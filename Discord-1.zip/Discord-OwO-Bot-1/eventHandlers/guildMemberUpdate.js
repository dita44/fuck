/*
 * OwO Bot for Discord
 * Copyright (C) 2019 Christopher Thai
 * This software is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International
 * For more information, see README.md and LICENSE
  */

// When guild member is updated
exports.handle = function(guild,member,oldMember){
	// Disabled due to new guild intent permissions
	// This is now handled by good ol' Snail Bot
	// this.patreon.update(guild,oldMember,member);
}
